% This is a script to answer analytical questions in the rocket lab
%
% Authors: Phil Miceli & Jack Soltys
% Date:    4/26/2021

%% Read in thrust data

data = readtable('Thrust.csv');

time = data(:,1).Var1;
thrust = data(:,2).Var2;

%% Plot data

figure
hold on

plot(time,thrust,'LineWidth',1.5)
title('Thrust Curve of F62T Rocket Motor')
grid on
xlabel('Time (s)')
ylabel('Thrust (lbf)')

hold off

%% Calculate Specific Impulse

ITotal = trapz(time,4.44822*thrust); % Total impulse is thrust integrated over time

mPropelant = 25E-3; 

Isp = ITotal/(9.81*mPropelant); % Calculated speific impulse

