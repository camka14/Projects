function [Ab,Vb,Vc] = burn_geometry(r_in, r_out, rb, h)
    
%  This burnback model only assumes burning with the cylindrical 
%  perforation of the grain.  Modify as needed for your rocket motor. 
    h0 = 1.505*0.0254; % [m] origonal grain height
    Vtot0 = pi*r_out^2*h0; % [m^3] origonal internal volume
    
    if rb >= r_out % motor is burnt out
        Ab = 0; % [m^2]
        Vb = 0;
        
    else % there is grain remaining
        %% BURN AREA
        h_new = h - 2*rb; %
        A_endcap = pi*(r_out - (r_in + rb))^2;
        A_cyl = 2*pi*(r_in + rb)*h_new;
        Ab = A_cyl + 2*A_endcap; % [m^2] total burn area for cylindrically perforated grai

        %% CHAMBER VOLUME
        Vc = Vtot0-pi*(r_in+rb)^2*h_new; % [m^3]
        
        %% VOLUME of PROPELLANT CONSUMED
        Vb = Vtot0-Vc; % [m^3]
        
    end     
end