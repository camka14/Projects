function [ThSM_en, Cstar] = thrust_calc(Pa, Pc, Ae, rho_p, burn_rate, A_burn, AR_sup)
    %Pc_en = Pc * 145.038; % [psi] chamber pressure

    %% Aerothermochemistry Data
    ERROR = 0;
    %try % tests if there is any output
        % OUTPUT1 GIVES VALUES IN THE CHAMBER
        % OUTPUT2 GIVES VALUES AT THE NOZZLE THROAT
        % OUTPUT3 GIVES VALUES AT NOZZLE EXIT
        [Output] = aerothermochemistry(Pc, AR_sup);
    %catch
    %   ERROR = 1;
    %end
    
    %if ERROR == 1 % sets Mach and alpha to zero if output DNE
    %    alpha = 0;
    %    Mach = 0;
    %    Pe = Pa;
    %    Cstar = 0;
    %    rho_g = 0;
    %else
        Tc = Output.T; % [K] chamber temperature
        gamma_c = Output.g; % ratio of specific heats
        MolWt_c = Output.MolWt; % molecular weight
        rho_c = Output.rho; % [kg/m3] gas density
        Cstar = Output.c; % [m/s] c* velocity
    
    % Add other aerothermochemistry parameters as needed
    Cf = Output.cf; % thrust coefficent
    syms M;
    M_solved = vpasolve((((gamma_c+1)/2) ^ -((gamma_c + 1)/(2*gamma_c - 2))) * ((1 + (gamma_c-1)/2 * M^2) ^ ((gamma_c+1)/(2*(gamma_c-1)))) /(M));
    %M_solved = vpasolve(eqn);
    Me = double(M_solved);
    if length(Me) == 0
        Me = 1;
    end
    Pe = Pc * ( 1+(gamma_c-1)/2 * Me^2 )^(-gamma_c/(gamma_c-1));
    At = 7.6660e-06;;
    rho_s = 0.05871*27679.9; % [kg/m^3] density of propelant
    
    %% MASS FLOW CALCULATION
    m_dot = (rho_s-rho_c.Value)*burn_rate*A_burn; % [kg/s] propellant mass flow rate
    
    %% THRUST CALCULATION
    %ThSM = m_dot*Cstar*1+; %[N] thrust SI
    ThSM = m_dot*Cstar + (Pe-Pa)*Ae;
    ThSM_en = ThSM * 0.224809; % [lbf] imperial thrust to match curve data