#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    float y;
    float x;
    cin >> x >> y;
    cout << x + y << endl;
    cout << x - y << endl;
    cout << x * y << endl;
    cout << x / y << endl;
    cout << pow(x,y) << endl;
    
    return 0;
}