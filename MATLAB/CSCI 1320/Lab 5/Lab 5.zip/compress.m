function comp = compress(soundVec, compratio)
% THIS IS A FUNCTION STUB RETURNING DUMMY DATA
% Compress by keeping every nth element
comp = soundVec;
end