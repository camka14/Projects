function fftbar(soundVec,Fs)
% THIS IS A FUNCTION STUB RETURNING DUMMY DATA
% Takes audio sampling frequency.
% Uses only first 1000 samples.
% Use fft to convert to frequency domain.
% Ignore imaginary component by using abs().
% Use the positive values only for plotting.
% Create a frequency vector.
% Creeat a bar graph with frequencies on the horizontal axis and amplitudes
% on the vertical axis.

end