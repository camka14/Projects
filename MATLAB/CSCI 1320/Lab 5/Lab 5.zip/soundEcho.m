function echo = soundEcho(soundVec, Fs, delay, echoGain)
% THIS IS A FUNCTION STUB RETURNING DUMMY DATA
% 1) Find delay in samples using Fs*delay
% 2) Add delay to soundVec and
% 3) Play new version of sound vector
echo = soundVec;
sound(soundVec, Fs, 16)

end