// Hello world to make sure we know how to compile a basic C++ program

#include <iostream>
using namespace std;

int main()
{
	cout << "Hello computer world" << endl;
	return 0;
}

